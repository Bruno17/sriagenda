<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 'sriagenda-1.0.0-beta1/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd662394d6589386ad99111439447a18d',
      'native_key' => 'sriagenda',
      'filename' => 'modNamespace/be3986997b824c626bfc46358fbef41e.vehicle',
      'namespace' => 'sriagenda',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '89b8a333065171201585516154b2ac2b',
      'native_key' => 1,
      'filename' => 'modCategory/e0afef1863f87c69f185cf77763300fb.vehicle',
      'namespace' => 'sriagenda',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bd7abcbc3e30464c5e22b0f3ae734821',
      'native_key' => 'Agendas',
      'filename' => 'modMenu/b1b1f280b0d6a3e7239f32cc9b64bf61.vehicle',
      'namespace' => 'sriagenda',
    ),
  ),
);