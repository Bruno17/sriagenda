<?php
require_once (dirname(dirname(__FILE__)) . '/sriagenda.class.php');
class sriagenda_mysql extends sriagenda {}