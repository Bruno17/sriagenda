<?php
class sriagenda_spk extends xPDOSimpleObject {}