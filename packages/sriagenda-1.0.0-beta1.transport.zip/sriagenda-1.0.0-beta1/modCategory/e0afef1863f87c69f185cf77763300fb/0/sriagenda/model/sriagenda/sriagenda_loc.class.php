<?php
class sriagenda_loc extends xPDOSimpleObject {}