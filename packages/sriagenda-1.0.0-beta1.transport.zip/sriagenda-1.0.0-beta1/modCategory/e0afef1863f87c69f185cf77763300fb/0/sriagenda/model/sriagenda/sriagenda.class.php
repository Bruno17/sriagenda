<?php
class sriagenda extends xPDOSimpleObject {}