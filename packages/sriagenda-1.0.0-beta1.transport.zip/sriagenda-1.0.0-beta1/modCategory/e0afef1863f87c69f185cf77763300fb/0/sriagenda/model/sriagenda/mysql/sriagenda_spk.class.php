<?php
require_once (dirname(dirname(__FILE__)) . '/sriagenda_spk.class.php');
class sriagenda_spk_mysql extends sriagenda_spk {}