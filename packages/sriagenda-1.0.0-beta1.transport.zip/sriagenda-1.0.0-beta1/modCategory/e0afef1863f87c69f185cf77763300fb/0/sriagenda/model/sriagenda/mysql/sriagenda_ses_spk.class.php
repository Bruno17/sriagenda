<?php
require_once (dirname(dirname(__FILE__)) . '/sriagenda_ses_spk.class.php');
class sriagenda_ses_spk_mysql extends sriagenda_ses_spk {}