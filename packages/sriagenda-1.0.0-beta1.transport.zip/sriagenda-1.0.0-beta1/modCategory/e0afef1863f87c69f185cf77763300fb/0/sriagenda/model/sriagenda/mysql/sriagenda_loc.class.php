<?php
require_once (dirname(dirname(__FILE__)) . '/sriagenda_loc.class.php');
class sriagenda_loc_mysql extends sriagenda_loc {}