<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'sriagenda',
    1 => 'sriagenda_spk',
    2 => 'sriagenda_loc',
    3 => 'sriagenda_ses',
    4 => 'sriagenda_ses_spk',
  ),
);