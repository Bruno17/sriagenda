<?php
require_once (dirname(dirname(__FILE__)) . '/sriagenda_ses.class.php');
class sriagenda_ses_mysql extends sriagenda_ses {}