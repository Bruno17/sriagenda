<?php
class sriagenda_ses_spk extends xPDOSimpleObject {}